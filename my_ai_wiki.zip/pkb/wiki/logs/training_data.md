---
type: research_import
source_file: podcast_training_data.md
imported_at: 2026-04-07T08:41:06.253Z
---

# AI Podcast: Training Data

> 共收集 1 期节目摘要。

---

## How Autonomous Labs Will Transform Scientific Research: Ginkgo Bioworks’ Jason Kelly

- **发布时间**: 2026/3/24 14:12:00
- **原始链接**: [点击查看](https://www.youtube.com/playlist?list=PLOhHNjZItNnMm5tdW61JpnyxeYH5NDDx8)

### 📜 内容摘要与转录

Speaker 1 | 00:00 - 00:14
All of the previous revolutions in tech, Internet, right, like social media, like whatever, have been totally meaningless to biotechnology and biopharma. Like, yeah, it's nice. We communicate slightly better or whatever. It's just some, like, back office IT crap. Right?

Speaker 1 | 00:14 - 00:28
Like, not this. Like like, this this is is actually gonna change the fundamentals of how we do science and and our big science industries like biopharma are gonna get disrupted. I I really believe that. And that's not been true for the last thirty years of tech.

Speaker 2 | 00:45 - 00:50
We are thrilled to have Jason Kelly, founder and CEO of Ginkgo Bioworks, with us today. Thank you for joining us.

Speaker 1 | 00:50 - 00:51
Yeah. Thanks, Sonya.

Speaker 2 | 00:51 - 01:04
So you started Ginkgo Bioworks in 2008 with the goal of making biology programmable. And programmable has taken on completely different meaning in the era of AI. So, I'm very excited for the conversation today. Maybe tell us about the journey so far.

Speaker 1 | 01:05 - 01:22
I mean, do the ginkgo journey in short, right? Yeah, we started in 2008, but we didn't actually raise any capital until 2014. We bootstrapped for four or five years. Yeah. Which, like, if you're not a bio person, this doesn't make sense, but in biotech VC, they really don't like young people, for example.

Speaker 1 | 01:22 - 01:27
So, we had started the company straight out of grad school. It was 2008. We weren't trying to make a drug, so we were totally uninvestable.

Speaker 3 | 01:27 - 01:31
Were you full time focused on the company for those first six years? Oh, yeah. Okay.

Speaker 1 | 01:31 - 01:50
Oh, yeah. Yeah. We were basically applying We did government grants and service business. It was pretty brutal And then summer fourteen, Sam Altman, now Mr. Famous, writes this blog post because he just took over YC, and he's like, Hey, I think the Silicon Valley model can work for deep tech, nuclear fission, biotech, material science.

Speaker 1 | 01:50 - 01:59
And so, I wrote him an email. Was like, Oh man, thank you for I mean, we're five years old. I got 15 people in a lab in Boston. We don't make sense for YC, but this is like an oasis in the desert. Know?

Speaker 1 | 01:59 - 02:07
Like, nobody will invest in weird companies like this. And he's like, No, you got to meet me. So, I flew out to San Francisco and met him. He's like, You should do YC. I was like, I should do YC.

Speaker 1 | 02:07 - 02:13
So, then we did YC. So, that was sort of when, if you really want to mark Ginkgo from having capital, it was sort of in 2014.

Speaker 2 | 02:13 - 02:15
And how has the product changed since 2014?

Speaker 1 | 02:15 - 02:26
Oh, well, so the mission hasn't changed, but the product has gone all over the place, different roads. So, we've always wanted to make biology easier to engineer. That was the idea. And so, if you're, this is a very much a big

Speaker 3 | 02:26 - 02:32
Hang on. I remember make biology programmable. Have the words always been make it easier to engineer? Yes. Because I feel like that's a slight

Speaker 1 | 02:32 - 02:40
I was always, when was talking to Sequoia, it was always like the computer science wrapper on make biology Easier to Engineer. But, yeah, that was always our mission.

Speaker 3 | 02:40 - 02:40
Okay. Got

Speaker 1 | 02:40 - 02:52
it. But the analogy's solid, right? So, you know, DNA is code, right? It's ATCs and Gs, not zeros and ones. It's really our only other, like, coded product other than computers is really biotechnology.

Speaker 1 | 02:52 - 03:18
So, the core idea of Ginkgo was, well, if you could design DNA code, you can program cells to do things. And cells are programmable like computers, right? But unlike computers, which just move information around, cells move atom around. So, if you can build whatever you want, that's, we think, ultimately going to be a huge market, a huge opportunity. But the challenge is our ability to program cells today is really bad.

Speaker 1 | 03:18 - 03:21
And so, how could you fix that? That was the core idea behind GIGO.

Speaker 2 | 03:21 - 03:24
And how has the product itself changed over time?

Speaker 1 | 03:24 - 03:43
Yeah. So, the way we to market it first was we're going to try to build what we called foundries, which was sort of a centralized laboratory that would kind of automate the lab work associated with doing biotech. And the reason, again, you're a computer scientist, the way to think about this is if you want to compile and debug DNA code, that's a physical process. Yep. Right?

Speaker 1 | 03:43 - 04:00
So you're like ATCGGG. Like, we have to do phosphorambitide chemistry. You got to build the piece of DNA you want and then put it into a cell, grow the cell, and test the cell, and that's your kind of compiledebug cycle. Does that make sense? And so one half of what we worked on technologically was how do we make that cheaper, right?

Speaker 1 | 04:00 - 04:31
Because if you want to get better at doing this, you've to do more of it faster and for less expense. And then the second thing we worked on was how do you get better at your programming? In other words, like that design you choose to test in the lab, how do you improve the odds that it does what you want? So sort of like get better at designing the biology and make it cheaper to try things were like basically for the last fifteen years, the twin activities. And in an era of AI, I see you see opportunities on both sides for that today, and that's we've shifted a little bit over the years in terms of how we do it.

Speaker 1 | 04:31 - 04:33
But does that make sense? Two kind of halves.

Speaker 3 | 04:33 - 04:41
And roughly speaking, the design piece sounds like it's a bit more software. The testing piece sounds like it's a bit more hardware, controlled by software.

Speaker 1 | 04:41 - 04:59
Very much. Okay. That's exactly right. And today, the folks leading on the design side, you might see companies like Chai Bio, for example, has these protein models, Bolt. The folks at Arc Institute just came out today with a paper, we'll call it, about EVO2, which is like a genomic model.

Speaker 1 | 04:59 - 05:12
There's a whole community of people now trying to solve the problem of designing biology with AI. The big change at Gingko over the last two years is I've kind of stopped working on that problem. I'm like, we had our own approach to solving it. It's hard, right? Designing cells is tricky.

Speaker 1 | 05:12 - 05:25
We're gonna try to solve this half of the problem, which is how do you make it cheaper and faster to try things in the lab, and how can you we could talk a little bit more. We did a project with OpenAI. How could you have AI models help you do that?

Speaker 3 | 05:25 - 05:37
Does anybody else focus on the back end, so to speak? I kinda think about design as the front end of the process and testing as the back end. When And I say anybody else, obviously, do this. Is anybody else with a similar approach focused on that part of the market?

Speaker 1 | 05:38 - 06:02
There you you're there's some new companies. Right? So there's companies like Medra out here as one that's doing it with, like, robotic arms trying to, accelerate it. You have, like, the life science tools industry, but I would say it does not have a Silicon Valley attitude about things in the sense that they're not really trying to change the fundamentals of how you do it. They're sort of like just providing the next tool to people doing it the way they've always done it.

Speaker 1 | 06:02 - 06:23
And so we've always been this kind of unique force trying to say, Hey, is there a new platform? Right? Is there something like the jump to planar semiconductor manufacturing in electronics at the beginning of Intel? You know, like, there some way we should just do all this stuff differently that could make it way better in the future? And that's always been the Ginkgo, like, what I think is unique about what we've been doing the last ten years.

Speaker 3 | 06:23 - 06:26
What catalyzed the focus on this part of the business?

Speaker 1 | 06:27 - 06:28
On the on this half of the house?

Speaker 3 | 06:28 - 06:28
Yeah.

Speaker 1 | 06:30 - 06:48
I think this is an engineering problem, and I think this is a science problem. Okay. So, and I went after both initially, and I kinda took my licks for that. And I think the good thing about an engineering problem is you can ultimately render it to dust. A science problem, I think, is great if you hit it, but it's much more unpredictable.

Speaker 1 | 06:48 - 06:56
And so in this era of Ginkgo, I've got the resources marshaled at this point to go after this and kinda see it through, and so that's why you see me pointing in that direction.

Speaker 3 | 06:56 - 07:09
And with the efforts that we see with the ARC Institute others of that ilk, what inning are we in, so to speak? Like, is the ecosystem around the science problem That's a good question. Going to start producing meaningful results soon other than papers?

Speaker 1 | 07:11 - 07:29
It's a good question. I think the hard part about designing biology so biology is amazing, by the way, right, like, just as a substrate again, right? Like, if you think about what's happening inside of a cell, it is producing, you know, Intel or now NVIDIA TSMC level caliber atomic placement basically for free.

Speaker 3 | 07:29 - 07:29
Yeah.

Speaker 1 | 07:29 - 07:36
Right? And so it's able to do molecular assembly. It self repairs. It self replicates. Like, as a as physical substrate, it's insane.

Speaker 1 | 07:36 - 07:52
It is the product of 4,000,000,000 years of evolution. So, the complexity embedded in a cell is actually a lot bigger, I think, than people give it credit for. And so, there's a march there. Now, said, more than half of your drugs today are produced by biotechnology. We cure cancer, we do this.

Speaker 1 | 07:52 - 08:09
We have huge value coming out of, even with the limited tools we have today. So, you don't have to solve the whole problem over here to create a lot of value. You just have to be better than how we do it today. Does that make And so, I think they have a really good opportunity. Already in the near term, with all the protein models, you're seeing that, right?

Speaker 1 | 08:09 - 08:14
Like, Chai just did a big deal with Lilly. Like, there's real opportunities there, I think, right in the near term.

Speaker 2 | 08:14 - 08:15
Yeah.

Speaker 1 | 08:15 - 08:15
Does that make sense?

Speaker 2 | 08:15 - 08:24
Mhmm. So speaking of OpenAI and Mr. Altman. You recently announced a partnership research result with them. Can you say more about that?

Speaker 1 | 08:24 - 08:43
Yeah, okay. So, this is pretty exciting. Think for the folks that are following AI, it's pretty neat. So, basically what we did was we took our, we call it an autonomous lab, right? And so, I can talk more about this, but the short answer is if you really want to drive efficiency on the lab side, you need to get the human beings off of the lab bench, right?

Speaker 1 | 08:43 - 08:55
So the way we do, and this is true in biotechnology, it's kind of true for science broadly. The way we do science today, 95% of science, the stuff that's not theoretical. So not math. You know, everybody's working on math. Like, let's work on Terence Tau.

Speaker 1 | 08:55 - 09:04
Let's get a Terence Tau in a box or whatever. Right? Like, you know, like the reason is that you can just simulate all that stuff on a computer. Let's play chess, you know, right? Like, yeah, no kidding.

Speaker 1 | 09:04 - 09:23
Right? But but if you look at the majority of like what we spend money on in The United States and just generally across the world in science, it's largely on experimental work. Yep. And the reason is if you want to learn something new about the world, which is what science is fundamentally, you have to go out usually and like poke it. You have an opinion of hypothesis, but you got to go test it to actually figure it out.

Speaker 1 | 09:23 - 09:47
So it's experimental science that moves the needle in my view. And so the question was, could a reasoning model do the work of experimental science if you gave it a robotic lab? That was the question. And the answer was, yeah, it's actually pretty damn good. So we did basically, the way the project worked was we had there's a biochemistry problem called cell free synthesis.

Speaker 1 | 09:47 - 10:09
So, you take a piece of DNA, ATCGGG, right? If you were to put it in your cell right now, remember, like, central dogma in high school, right? Like, it's like DNA makes RNA makes a protein, right? And so, you put that DNA into a cell and it'll make a protein. Well, you can do a thing called cell free where you pop a cell open, take the guts, put it in a test tube and then add the DNA to that.

Speaker 1 | 10:09 - 10:33
And because the guts are still there, it makes the protein. So this is kind of like it's like the world's smallest three d printer or something. And so scientists use this, they try to optimize, it's very expensive usually. And so there was a paper that came out of Stanford from Mike Jewett's lab in August that set the benchmark for how cheap people had been able to do cell free protein synthesis. And so we said, all right, let's try to optimize that with the model.

Speaker 1 | 10:33 - 10:53
And so we gave the model we did each round, we would do one hundred three eighty four well plates. Okay, so each well in a plate is like a little kind of cup of liquid and you can do an experiment in there. And so we gave it, you know, 30,000 experiments to run. And after it would run those experiments, gets the data back and designs another set. So after four rounds of that, we beat state of the art.

Speaker 1 | 10:53 - 10:56
And after six rounds, we beat it by 40%.

Speaker 2 | 10:56 - 10:57
Wow.

Speaker 1 | 10:57 - 11:05
And so that was a I think it's the most interesting sort of model doing experimental work result that's been shown to date by a lot.

Speaker 3 | 11:06 - 11:11
And the 40% was a function of what? Just faster cycle time or more intelligent experiment design?

Speaker 1 | 11:11 - 11:39
Yeah, like how did it beat the So state of the this my point. This is, I think, my larger point about science, because I think we're gonna do science differently in the future, in based my on what I'm starting to see here. So, what does the scientists do when they're doing experimental work? They're coming up with an idea, and then they're trying to design an experiment to ask a question about that idea. And then they're gonna run the experiment, take the data back, interpret it, and then poke again based on what they learned.

Speaker 1 | 11:39 - 11:50
And they're going to go through that process a few times to resolve something. Oh, this is how, you know, whatever, this cancer works. This is how this piece of materials works. This is this. This is that.

Speaker 1 | 11:50 - 12:01
And so that cycling is just logic. Yeah. Right. And so it doesn't require you to model biology or simulate anything. It's not that half of the house.

Speaker 1 | 12:01 - 12:13
It just requires you to be almost like a programmer. Like you need to be logical, run through a set of things, do data analysis and draw conclusions. And so that's all it has to do. Does that make sense? Yeah.

Speaker 1 | 12:13 - 12:21
And so, we didn't do anything other than that. Okay. Right? What really let it break through wasn't that it was so smart. It was that it could run experiments.

Speaker 1 | 12:21 - 12:25
And the question was just, could it design them like a scientist could?

Speaker 3 | 12:25 - 12:25
Mhmm.

Speaker 1 | 12:25 - 12:33
And the answer was, yeah. Hell yeah. It could. And so now I think that opens a real interesting question about, like, how we do science in The United States.

Speaker 3 | 12:33 - 12:45
Well, it's easy to imagine a version of the future in which the, you know, the scientific method and the design and the hypothesis testing and all that is done by reasoning models of some sort, and the actual testing is done by ego.

Speaker 1 | 12:45 - 12:46
Autonomous labs.

Speaker 3 | 12:46 - 12:56
You know, Autonomous labs. Yeah. What's wrong with that vision of the future? And if and if that is the right vision of the future, how far out is it? I mean, I think this is how it's gonna happen.

Speaker 1 | 12:56 - 13:10
I I really do. Like like the, I mean, I'm probably more substantially more aggro on this than, like, the average scientist today. But, like, it's so I'll just explain, like, why it wore I think if you, like, had a heads up competition, which I wanna do this. Right?

Speaker 3 | 13:10 - 13:15
So And then tell me how the average scientist would push back and say, no. No. No. It's not gonna happen that way because.

Speaker 1 | 13:15 - 13:28
Right. So I think what the what the scientists will push back on is, like, this thing can just be as creative or as me or something. Right? Which I actually I I'm sympathetic to that. Yeah.

Speaker 1 | 13:29 - 13:32
I'm not saying it's gonna be more creative. I'm saying

Speaker 3 | 13:33 - 13:34
It's gonna be way more creative.

Speaker 1 | 13:34 - 13:47
I'm saying you don't yeah. No. Not that Silicon Valley. I live in Boston. I mean, I'm saying it it can run a lab twenty four hours a day.

Speaker 3 | 13:47 - 13:47
Yeah.

Speaker 1 | 13:47 - 13:55
It I'll give you another example. Like, the way science works today is you would have a lab, you'd have a lab, I'd have a lab. We're all working on the same area. Let's say we're working on, like, Alzheimer's.

Speaker 3 | 13:55 - 13:55
Yeah.

Speaker 1 | 13:55 - 14:01
You have hypothesis. You have hypothesis. I have hypothesis. We each kind of pursue it. We're collecting data over the course of a year or two.

Speaker 1 | 14:01 - 14:14
And then based on what I see at the end, I write a paper. And when it comes out in the published literature, you get to read it and you get to read it. And you're all doing the same thing. So we're kind of like exchanging information every year or two. And I'm not getting to see every experiment you did, by the way.

Speaker 1 | 14:14 - 14:19
I'm getting like the distilled output of what you think you saw over two years. Does that make sense?

Speaker 3 | 14:19 - 14:19
Yeah.

Speaker 1 | 14:19 - 14:31
All right. So let's contrast that to like what I think should start to happen now based on what I saw with this open AI project. What I think should happen now is you should have a robotic lab that has every piece of equipment that we all have in our labs. So it can run any experiment you want. We can talk in a minute.

Speaker 1 | 14:31 - 14:43
That's actually a pretty technically difficult problem, but let's just wave that away. Okay, solved. All right, great. So then I'm going to put 100 AI scientists on top of this thing. Each one is going to pursue a different hypothesis for Alzheimer's.

Speaker 1 | 14:43 - 14:59
All right, great. And they're going to run their experiments just like you would in your lab that day. But at the end of the day, they're going to pass the data on those experiments, like what experiment they ran and the raw data that came off it to the other 100 eyes. Yep. Daily, every fucking day.

Speaker 1 | 14:59 - 15:14
Okay. And so they're going to learn from each other like you're even though your hypothesis is different, we're working in the same area. Yeah. So your failed result might like, for example, say your experiment went the wrong way from your hypothesis. That data might be relevant to my hypothesis, and I would never see that normally.

Speaker 1 | 15:14 - 15:29
Does that make sense? Yep. And so that's all just shogging along. And every week it dumps, you know, a lab notebook entry or like a mini paper, like a conclusion about what the 100 of them have figured out that week that we can all read and see and use that. We can direct.

Speaker 1 | 15:29 - 15:46
We say this, hey, cut that line of research or whatever. And so, that's number one. I think the information sharing and like the ability to handle like really broad context across a lot of projects for the AIs is just better than it's just socially different even than how we do it today. Does that make sense? That's unfair advantage number one.

Speaker 1 | 15:46 - 16:03
Okay, unfair advantage number two. If you look at how we spend money in science, remember all this stuff like the NIH was like, what's up with the indirect rates at academic universities and all this hullabaloo, right? Well, what's an indirect rate? Well, it's basically paying for manual laboratories. That's what it pays for.

Speaker 1 | 16:03 - 16:14
Okay, you've got these labs and they're there 20 fourseven, but they're used five days a week. Yep. Okay, they have equipment. But every lab, all three of our labs, we have same copies of the same equipment. Yep.

Speaker 1 | 16:14 - 16:19
Because we all got to do the same work. We don't share each other's. No, no, no. I like a door in my lab. Only my lab gets to use it.

Speaker 1 | 16:19 - 16:37
Your lab uses yours. So we have all low utilization rate of our equipment. Just how it works. Okay, right. And so you have a very inefficient like if you look at the spending on research and this is true, the 60 to $80,000,000,000 a year that biopharma spends or the 40,000,000,000 that NIH spends less than 5% is on the reagents.

Speaker 1 | 16:38 - 17:01
Everything is on overhead. It's basically overhead, the people, the regulatory, the lab space. If we were running it efficiently, you would budget a research program at the NIH not on interact and heads and everything else, but just on the reagents, because that's like the usage based pricing of science. Yeah. Because to actually do experimental work, I have to consume some chemicals.

Speaker 1 | 17:01 - 17:12
I have to consume a piece of plastic plateware, like whatever the hell it is. Like, I'm actually doing atoms in the physical world. I got to burn some stuff up. That should be the dominant cost. It's the opposite right now.

Speaker 3 | 17:12 - 17:12
Yes.

Speaker 1 | 17:12 - 17:23
It's like less than 5%. So the other advantage those eyes will have is if they're able to run robotic labs, now they're running where 90% of the cost of a research project goes to the reagents.

Speaker 3 | 17:23 - 17:23
Yes.

Speaker 1 | 17:23 - 17:33
Oh, my God. Right. So that's like a 10x increase in the amount of data per dollar that you're getting compared to how we do it today. So I think you combine those two things. But without the AIs even being smarter, right?

Speaker 1 | 17:33 - 17:43
They can even be dumber than the scientists. I think they win. I really think they win. And so I think we got to reevaluate, like, how we fund what we fund with the NIH. I think every biopharma head of R and D needs to care about this.

Speaker 1 | 17:43 - 18:04
Like and I think there's a blind spot, by the way, like we did YC. I know all the tech people and the tech, you know, so you guys I've always been adjacent to this stuff, right? All of the previous revolutions in tech, Internet, right, like social media, like whatever have been totally meaningless to biotechnology and biopharma. Like, yeah, it's nice. We communicate slightly better or whatever.

Speaker 1 | 18:04 - 18:17
It's just some, like, back office IT crap. Right? Like, not this. Like, like, this this is is actually gonna change the fundamentals of how we do science, and and our big science industries, like biopharma, are gonna get disrupted. I really believe that.

Speaker 1 | 18:17 - 18:20
And that's not been true for the last thirty years of tech.

Speaker 3 | 18:20 - 18:32
Well, our partner, Constantine, has a good framework for that. He talks about how there are revolutions in computation and revolutions in communication. Yes. Communication is about the distribution of information. Computation is about the processing of information.

Speaker 3 | 18:32 - 18:43
Yes. And what you're talking about here is just a different way to process the information. Like, and so the last several revolutions have been about the distribution side of the equation, which doesn't get to the core of what it is you're doing.

Speaker 1 | 18:43 - 19:01
Completely agree. And that's, I think, fundamentally true. So, again, I think the leaders, biopharma companies and also the leaders of research universities and these people that are in the business of doing science to produce either products for the government, Cannot ignore this. They cannot ignore AI. It is just different.

Speaker 1 | 19:01 - 19:09
And I'm telling you, I'm a person who has been adjacent to this crap for fifteen, twenty years now, and this is the first time I've like, the tech guys finally did something cool. Yeah.

Speaker 2 | 19:10 - 19:18
And just so you understand, like, so you think AI is the catalyzing force behind you know, Cloud Labs should be a thing. Nobody really ever moved to them, but, like, AI will be the reason they move.

Speaker 1 | 19:18 - 19:23
Yeah. Well, we can talk about Cloud Labs. Yeah. So so let's talk about Autonomous Labs, and then I'll explain Okay. The Alright.

Speaker 1 | 19:23 - 19:31
So, why has it been hard? Right? Like like, the average tech person's looking at how science is done, where you have literally PhD trained people. These are brilliant people.

Speaker 3 | 19:31 - 19:32
Yeah.

Speaker 1 | 19:32 - 19:46
Paid decent amount of money standing I I I did a PhD at MIT in bioengineering. It's five years of moving liquids around a lab bench by hand. I swear to God. Like like, it it is like like like my friends from undergrad just like they would never. Right?

Speaker 1 | 19:46 - 19:50
Like, you know, right? Like, it's ridiculous. You would do, like, manual labor, right? Like, absurdity, right? Our group.

Speaker 1 | 19:50 - 20:02
The the, but, like, that's what you have to you have to do that. If you want to play at the edge of science, you got to do physical work. And so that's what you learn to do. Okay. And so it's like, well, everyone in Silicon Valley is like, well, automate it, bro.

Speaker 1 | 20:02 - 20:13
Like, you know, like, like, why don't we just do that? Okay. So why is it why is it hard? All right. And the reason it's hard is it's like the technical, like automation term is like high mix, low volume work.

Speaker 1 | 20:13 - 20:32
Yeah. Okay. And this is true at like places like Hadrian today, for example, that are working on this on the manufacturing side, industrial high mix, low volume is hard to automate historically. All right. And my like transportation analogy that I've been giving to people in bio is like, okay, so imagine on the Y axis you have like level of automation.

Speaker 1 | 20:32 - 20:52
Yep. And then on the X axis, you have like flexibility, like that variability, the mix in what you're being you're asking it to do. So in transportation, low mix, high automation, that's like a subway. Sit down, takes you away, right? Like, you know, maybe you're like, don't have to do anything, but you got to want to go to one of the stops on that subway line.

Speaker 1 | 20:52 - 20:57
Yep. Low automation, high variability. That's car. Yep. Right.

Speaker 1 | 20:57 - 21:17
Hands on the wheel, foot on the pedal, take you out to your house or the grocery store. And that's what the transportation system looked like for the last hundred years until. Thank you very much. You know, Google, we got Waymo up here in the corner where you get the flexibility, you know, the automation of a subway, but the Okay. Flexibility And of a it's so surprising that we don't even call it automation anymore.

Speaker 1 | 21:17 - 21:30
We make up a new word. We call it autonomous. It's autonomous car. Because the way I look at it is since the industrial revolution, we've basically been automating everything that is low mix. That's like low variable from the lume on.

Speaker 1 | 21:30 - 21:38
Okay, right. And we just hit a wall and AI. We hit a wall on flexibility of what you can do, and AI pushes us past it.

Speaker 3 | 21:38 - 21:39
Yep.

Speaker 1 | 21:39 - 21:56
That is like every part of the physical like our physical infrastructure post industrial revolution. Everything has to get looked at again with that lens as we move up the variability. Does that make sense? And so that's what we're so like, that's the tricky bit in like lab land. We actually have automation, but it's like subways.

Speaker 3 | 21:56 - 21:56
Yes,

Speaker 1 | 21:56 - 22:14
it's just repeat the same experiment, you know, at a diagnostic company like Quest, they would have automation. If you're a high throughput screening in pharma, there's automation, but it can't do the variability. So 99% of the work, just like 99% of miles traveled, is in cars. 99% of the lab work is still at the frickin bench. Yeah.

Speaker 1 | 22:14 - 22:15
And that's what you gotta fix.

Speaker 3 | 22:15 - 22:23
And what's and so, like, the Waymo analogy is an interesting one, because it's now such a magical thing that so many people have gotten to experience.

Speaker 1 | 22:23 - 22:23
Yes.

Speaker 3 | 22:23 - 22:37
And in that case, you know, you kinda had your sensor suite. You know, you have your radar and your LIDAR and your cameras. Yeah. You know, then you had your software suite with the perception and the planning and the actuation, which then had to tie back into Yeah. You know, whatever vehicle manufacturer you're working with.

Speaker 3 | 22:37 - 22:46
And then there are a gazillion corner cases that you have to simulate Sure. Because you can't get enough of them in the real world. Mhmm. Like, what would that set of words be for your world? Yeah.

Speaker 1 | 22:46 - 22:46
Great question.

Speaker 3 | 22:46 - 22:49
What are all of these specific things that are hard to get right to?

Speaker 1 | 22:49 - 22:56
100%. And and I think if you're, like, trying to generalize the problem of bringing automation to autonomy Yeah. It's gonna be different in every domain.

Speaker 3 | 22:56 - 22:56
Yeah. So for

Speaker 1 | 22:56 - 23:04
cars, the hard part is the physical world is changing. Yeah. Every mile you drive, the world, oh my god, I'm in a new place. Right? Like, this one has a cone.

Speaker 1 | 23:04 - 23:07
It's raining. Like, whatever. Right? Like, that's not the problem in the lab at all. Yeah.

Speaker 1 | 23:07 - 23:14
Lab, I can make it it's my lab every day. It's the same fucking room that the robots are. Nothing is changing. Okay. The physical environment is not changing at all.

Speaker 1 | 23:14 - 23:30
Yeah. So like like it is not at all the same stack that brought you autonomous cars that will bring you autonomous labs. That's not my problem. Okay. So in my world, it's the variability in like what the scientist is asking for that makes it hard.

Speaker 1 | 23:30 - 23:35
Right. So they're like, I want to use this piece of equipment. I want to use that piece of equipment. This is my combination of things. Right.

Speaker 1 | 23:35 - 23:48
And so one of your big problems is getting a thousand long tail pieces of third party, like, you can't believe the software on these things, benchtop lab equipment. Okay. Integrated into one big system.

Speaker 3 | 23:48 - 23:49
Okay.

Speaker 1 | 23:49 - 23:59
So they all can be controlled by your software. That's like problem number one. It's like integration of benchtop equipment. Problem number two, what are we doing with our hands when we do science? Largely in bio anyway, it's liquid handling.

Speaker 1 | 24:00 - 24:28
So you pick up a pipette, which is like, if you didn't do this in high school, it's like the world's fanciest straw. And you like suck up a little bit of liquid and you squirt it out in the right spot. Like, but the thing is, if the liquid is viscous, like it's like syrup, then you do naturally with your thumb, like adjust the pressure of the straw because you can see with your eye if it's working or not. That's actually liquid handling turns out to be a trickier, like, problem than you think. And you are doing some work as the human to, like, manage that.

Speaker 1 | 24:28 - 24:37
So you have two big buckets. One, solve liquid handling. Two, send samples to a thousand different pieces of equipment. Does that make sense? Yep.

Speaker 1 | 24:37 - 24:39
If you nail those two, you're done.

Speaker 3 | 24:39 - 24:41
Well, that sounds that sounds tractable.

Speaker 1 | 24:41 - 24:47
It is fucking tractable. Yeah, I agree. Yeah, it's totally tractable. And so it's just a lot of work.

Speaker 3 | 24:47 - 24:49
Are you guys in, like, working through that?

Speaker 1 | 24:50 - 24:52
I think we basically have it working. Yeah. That's the honest truth.

Speaker 3 | 24:52 - 24:55
I mean, we we basically What's the last, like, major hurdle?

Speaker 1 | 24:55 - 25:08
One reason it's hard for people to do this technically is they wanna build the hardware Yeah. But they don't do research. So they kind of have to go to a customer and be like, Hey, you want to use my robot? Customer's like, No. Right?

Speaker 1 | 25:08 - 25:34
Like, they're at the bench. They're like, No, I don't want to try. So there's like an adoption issue that I think has made it really hard. And and so we have this advantage that because we have a research, we saw like our original business, which was research partnerships, which we still do, means I have a bunch of scientists employed at Ginkgo. These scientists are basically like, remember the Google engineers that, like, sit with their hands like this next to the wheel five, seven years ago in Palo Alto, like grabbing it if it like the way Moe drove into a mailbox or something, right?

Speaker 1 | 25:34 - 25:44
Like, yeah, that's my scientist today. Yeah. So they are they're dogfooding on our We have, like, 50 robots. We're going to 100 in our big lab in Boston. And so, they're the ones, like, trying out and breaking it.

Speaker 1 | 25:44 - 26:07
Things that have broken. Running a bunch of work in parallel across that system is a scheduling challenge. So, you know, you have to be able to manage all that. So, like, handling the scheduling with tight timing on experiments is, like, algorithmically tricky, we've to figure out a bunch of stuff. Getting the equipment to work all, like, it works all day long, making that reliable compared to it being barely used at the lab bench, that's tricky.

Speaker 1 | 26:07 - 26:12
So, there's just these, like, things that we have to keep knocking down, but they're engineering at this point.

Speaker 2 | 26:12 - 26:14
And have you solved, like, pipetting and Yeah, liquid

Speaker 1 | 26:14 - 26:30
the good thing is there is a whole industry that's worked on that problem, like liquid handling robotics. It's just a matter of having, like, all the different liquid handlers. And if you have them all, you can kind of and you know your your liquid class you're dealing with, you can manage it. Oh, one other one. Big one.

Speaker 1 | 26:31 - 26:35
Scientists don't code. Yep. Okay. So. Oh, cool.

Speaker 1 | 26:35 - 26:42
I use my robot. This is what everybody's done. They've made like visual programming languages. Like if you're a scientist, there's a thing called LabVIEW. It's like complete trash.

Speaker 1 | 26:42 - 26:49
But like it's, you know, make a flowchart, right? Because you can't write Python or whatever. Horrible. Okay. Like even that they hate.

Speaker 1 | 26:49 - 27:01
Okay. Right. And so no one will program shit. And so we ran to this issue where we now have all these scientists using the automation directly. So like, I don't know, three weeks ago or something, we had do two instances where we sent a plate.

Speaker 1 | 27:01 - 27:21
So like, again, this is like kind of a bunch of little wells with liquids in them and and we seal the plate when we put it in storage so it doesn't evaporate. So they sent a sealed plate to the pipetting robot and pipette comes down and it gets stuck in the seal. You're like, and people on our slack are like, Hey, what the hell? You know, like, deseal the plate before you send it to the liquid handler. Dum dum, right?

Speaker 1 | 27:21 - 27:32
Like, you know, and it's like and this is horrible for a scientist who is basically an expert at liquid handling at the bench. And now they're like making like, you know, basic mistakes here and they feel horrible. That's a bad UI. Okay. And I was just like, This is nonsense.

Speaker 1 | 27:33 - 27:54
We're from now on only what the way we're going to interact with writing the code is through Claude code or Codex. Yep. Like, you will now submit a written protocol of what you want, and the model will figure it out. And if the model sends a plate sealed, we will update the skills file, and it will never do it again, and we will get through this. Oh, And that's so that is a big win for usability

Speaker 3 | 27:54 - 27:55
Yes.

Speaker 1 | 27:55 - 27:59
Of robotics for scientists is what's happening with with cloud coding coders. Yep. Does that make sense?

Speaker 3 | 27:59 - 28:00
That does make sense.

Speaker 1 | 28:00 - 28:14
So, like, thank you. You know, right? Like, so these are the things that, that's, like, had to get knocked down too. And so all this is in flight. But, like, right now in Boston is, like, a very unique experiment happening where we have, like, 50 scientists submitting jobs into one big robotic setup.

Speaker 1 | 28:14 - 28:18
That exists nowhere else on the planet right now. So it's pretty neat to watch it.

Speaker 3 | 28:18 - 28:18
That's

Speaker 2 | 28:18 - 28:21
cool. Do you see a future for humanoids? No. Really?

Speaker 1 | 28:21 - 28:22
In the lab?

Speaker 2 | 28:22 - 28:41
Because because and the best argument I've heard for humanoids is, like, the world, the physical world Yeah. Is designed And, for like, I would think that the existing labs are made for humans walking around, pipetting things, walking between different machines. And so you try to create a robotic arm that's able to orchestrate all this, or you could just have a humanoid do what a human lab scientist does.

Speaker 1 | 28:41 - 28:49
Yeah. So again, the primary thing that the human is doing is moving samples around the environment.

Speaker 2 | 28:49 - 28:50
Yeah.

Speaker 1 | 28:51 - 29:04
There are much better ways to do that than walk them bipedally among things. You just put them on a track. Our system has a nice little track, and the plates move with extremely high liability. They get delivered with micron specificity to where they are. The arm picks them up.

Speaker 1 | 29:04 - 29:11
It's like, know, that problem just disappears. Okay. And then the other reason is, in the long run, humans are the limitation.

Speaker 3 | 29:11 - 29:11
Yeah.

Speaker 1 | 29:11 - 29:20
Right. It's not like, oh, humanoid robots going to disrupt TSMC? Are they going to go in there and etch the fucking chips? Like, obviously not. You know, right?

Speaker 1 | 29:21 - 29:29
Like, no, it's a microscopic discipline. Biology's a microscopic discipline. Like, these things are no. Yeah. Makes no sense.

Speaker 1 | 29:29 - 29:29
Yep.

Speaker 3 | 29:30 - 29:39
How does it change the unit of scale for a lab? Like, I'm I'm imagining that labs in the future are gonna be these enormous things the way that data centers have become these enormous things.

Speaker 1 | 29:39 - 29:53
So it's actually gonna make them smaller. Really? Okay. Because, again, you've probably not seen this, but, like, if you were to walk through Merck's campus, you'll see a million square feet of laboratory benches across a bunch of different buildings everywhere, whatever. Right?

Speaker 1 | 29:53 - 30:21
And they're they're set up for basically humans to be able to walk in and find a piece of equipment again, underutilized, but basically available whenever they need it to run whatever experiment they've come up with by thinking over the last two weeks and not even working in the lab. And so like that kind of like cycling is kind of how it operates. And you need it local. Like if you have a team now in this new place because you bought this company, they need a lab to replicate another lab, right? The labs have to go wherever your scientists are.

Speaker 1 | 30:22 - 30:42
Well, let's now instead imagine the scientists are ordering all their experimental work through computers and it's going to some centralized autonomous lab. You can think of that like a local cloud if you want. Okay, well, now you don't need a lab where the scientists are. So you get rid of all the just duplication that you have because of physical people. You also get wildly better utilization of the benchtop equipment.

Speaker 1 | 30:42 - 30:57
Like, we're talking going from, like, sub 20% utilization at the bench to, like, 70%. So now you need less equipment. And then, assuming you didn't decide to have humanoids, like, you can just jam it all in around a track system, so it's actually a lot tighter. Yep. Yeah.

Speaker 1 | 30:57 - 31:15
So we have, like, a major space reduction at the moment. That's one of the big savings. Like, when we talked to like, we just sold 97 robots to the Department of Energy for this, like, Genesis mission. This is, like, the AI for science thing that Trump's doing. And, like, that is basically gonna be ultimately much more dense than the equivalent set of labs would have been that would have, like, housed that otherwise.

Speaker 1 | 31:15 - 31:26
And that's part of the sales pitch. It's like, you could have less spending. Remember I told you earlier, like, the spending is not on the reagents, it's on basically roof space, laboratory space, and people.

Speaker 2 | 31:26 - 31:30
What is the unit of work? You said you sold 97 robots. Is that 97 boxes? Yeah,

Speaker 1 | 31:30 - 31:44
so our particular device, we call it a rack, it's like a reconfigurable automation cart. It's basically like a box that has a piece of benchtop equipment in it, a six axis robotic arm. This is like nothing special for labs. This is like traditional. This is like coming out of manufacturing tech.

Speaker 1 | 31:44 - 31:58
And then a piece of Maglev track. And what you do is you Lego block the carts. So we have like 50 of them all together in our lab in Boston. And then a sample can move on the track, and in front of every piece of equipment is an arm. And the arm picks it up and puts it on the equipment.

Speaker 2 | 31:58 - 31:59
Got it.

Speaker 1 | 31:59 - 31:59
Okay, does that make sense?

Speaker 2 | 31:59 - 32:00
Yeah.

Speaker 1 | 32:00 - 32:23
Yeah. And so our unit is, we sell the box, we sell like a subscription, basically, like service fee plus software subscription per box. Yep. And then eventually, what I want to sell is, like, automation friendly reagents because that's kind of like the usage pricing. So, that's like one half of my business now, is like, I'll build you an autonomous lab, you know, Pacific Northwest National Lab DOE or Merck or whoever.

Speaker 1 | 32:23 - 32:29
And then the other half is what you said. I'll run my lab in Boston as a cloud, and you can just order from it.

Speaker 2 | 32:29 - 32:42
Totally. Can we talk about training? Like, a lot of what we've been talking about, to me, seems like inference. Like, it's a use case of the reasoning. Seems to me that you are generating an enormously helpful dataset here that should be used to back prop into the weights themselves.

Speaker 2 | 32:42 - 32:44
Yeah. How's that gonna play out?

Speaker 1 | 32:44 - 32:59
That's a good question. I don't know yet. I think there'll be one training So there's two different levels of challenges. One was I think I mentioned earlier, like you're submitting a piece of physical work. And again, I think this applies to labs.

Speaker 1 | 32:59 - 33:11
This will also apply in like light manufacturing. Right. Like you want to do a slight oh, you're like a prototyping shop or whatever, any place where there's like variability. Okay. And so I see a lot of variable requests from scientists.

Speaker 1 | 33:11 - 33:15
I see all the edge cases of how it breaks the physical equipment.

Speaker 3 | 33:15 - 33:16
Yeah.

Speaker 1 | 33:16 - 33:20
That you can't like compile out. Yep. Make a digital twin. No. Like, you know, right?

Speaker 1 | 33:20 - 33:40
Like, like, have to, like, actually do this stuff. Like, I do not think like I don't buy it, right? Like, like a lot of it's edge case y, but, you know, liquid classes, you can't really pick it up on a camera. It's just like all this stuff that are like the edge cases that Waymo had to see driving around are edge cases we see by doing a lot of variable work on the same system. That is one type of training.

Speaker 1 | 33:40 - 33:45
I don't know that it's fully like model training as much as it probably is just like a giant file or something, but like that's one.

Speaker 3 | 33:45 - 33:45
Does that

Speaker 1 | 33:45 - 34:04
make sense? The bigger one is sort of the model's ability to take your intent and turn it into an experimental plan. And that's interesting. That's back to like, could these things just like blow science out of the water? And that I think you could have a really cool loop that has more to do with the results of every experiment.

Speaker 1 | 34:04 - 34:21
Like this open AI project, like as we saw what experiments worked and didn't, you could theoretically then teach the model to be a better scientist. It's like Newton, Einstein, like, you know, like these are the people that move the species forward at the end of the day. Right? Like everything else is kind of noise. We're just going around in circles, you know, like the Romans did it, you know, right?

Speaker 1 | 34:21 - 34:36
Like we're just doing the same stuff, The Greeks. But except for science. Right? Does that make sense? And so I do think this is like, if you crack that nut, like if you can if models plus again, I think you've got to have the experimental work.

Speaker 1 | 34:36 - 34:45
If that really 10x or 100x is the speed we do scientific discovery, that 10x or 100x is the progress of the species in my

Speaker 2 | 34:45 - 34:53
Yeah, yeah. It just seems to me that the results of what you're generating in the lab need to feed back into updating the model weights somehow. Otherwise, we're not gonna get to that point.

Speaker 1 | 34:53 - 35:17
I agree, but I think that's totally doable. Like, I think that loop, and I think this is something that the frontier models are starting to care about. Like, getting better at that, I do think, again, in my view, some of the most important part of human intelligence is our ability to push the frontier of knowledge. Mean, spreadsheets are cool too, you know, right? Like doing back office for a dentist, also fine, you know, right?

Speaker 1 | 35:17 - 35:23
Like, can make money with that. But, like, if we really want them to be smart, this is where it matters the most.

Speaker 3 | 35:23 - 35:26
I agree. You mentioned Project Genesis earlier.

Speaker 1 | 35:26 - 35:27
Yeah.

Speaker 3 | 35:27 - 35:28
What is it? Why does it matter?

Speaker 1 | 35:29 - 35:50
Yeah. So this has came out of, White House and OSTP, so the Office of Science and Technology Policy, like my there. And, and so, it's run by the Department of Energy, and that's in part because the Department of Energy is, if you're a science nerd, that's where we do our big science projects. Okay. So, like, starting with the Manhattan Project, but also the Human Genome Project actually was a Department of Energy project.

Speaker 1 | 35:50 - 36:15
So when it's project based, it kinda tends to live in Department of Energy and more open ended sciences like the National Science Foundation. Okay, so DOE's running it, so it's a project, and so they're like, All right, great, we're gonna have a list, and they actually put out a list of like, These are areas where we would like to see breakthroughs that are relevant for the American public. Yep. Okay, one of them, you know, a couple of them are bio related, but there's other stuff too, material science, new energy, all these different things. Right?

Speaker 1 | 36:15 - 36:39
And then what we want to do is bring AI models into the national labs, which is where we do a lot of our big science in the country, and accelerate them. And their target is to double the acceleration of science in the next few years. All right? So that's the idea. And so one way you're going to do it is they want to take the existing data that is at the national labs and, like, basically feed it in the models and see if you can find new stuff data we've already collected.

Speaker 1 | 36:40 - 37:08
But then the other way they want to do it is to have autonomous labs that can generate new data in the direction of models. And so, when we did that deal with the Department of Energy, Secretary, Department of Energy Secretary Wright and I, like, ribbon cut the first 18 robots up in Washington, he, like, signed it. It was really cool. And so, like, I think that's a to me, again, as a science nerd, like, that's a good push for us. And I think you want to see some good results soon because ultimately, they gotta You know, Congress has to get excited about this.

Speaker 1 | 37:08 - 37:13
You'll need, like, a bigger bolus of money in the future, right, to really make it a big deal. But I like what they're doing. Like, I think

Speaker 3 | 37:13 - 37:16
it's Well, a great a dream scenario, what does that do for America?

Speaker 1 | 37:16 - 37:39
So I I chaired this, National Security Commission on Emerging Biotech in DC for, like, two years, and Senator Young in Indiana chairs it now. And there was a similar one on AI that Eric Schmidt shared, like, seven years ago. So it was super fascinating to see, like and it like, learn more about DC, number one, Congress. And but also, like, the point is, how does The US stay competitive in technology areas that are strategic? Yep.

Speaker 1 | 37:39 - 38:05
And so there's one for cyber, like, fifteen years ago or something, then there was AI, and then this was on on bioengineering, biotech. We have had an unfair advantage, like, since the Soviet Union fell, basically, where, like, we were automatically at the lead in science. Like, there was no one else that had the money to spend on science, basically. And because science is like it's not just spending on the science. You also need scientists.

Speaker 1 | 38:05 - 38:15
So you have to have research universities to train these people. Like, it is esoteric. So that was true. That was true. And now with China's rise, it's not true anymore.

Speaker 1 | 38:15 - 38:26
Right? Like, they're actually like, if you look at the number of, like, scientific papers published, it's more from China now. If you look at in my world, like biotech drugs, not manufacturing drugs, like making new drugs.

Speaker 3 | 38:26 - 38:26
Mhmm.

Speaker 1 | 38:26 - 38:41
The way it works in this our industry is like a startup discovers a drug and then they try to sell it to Merck or Pfizer. And they're they're kind of go to market channel. And Merck or Pfizer buys it for 2,000,000,000 or 5,000,000,000 or 10,000,000,000, depending on where it is in like clinical trials. Yep. Great.

Speaker 1 | 38:41 - 38:47
Three years ago, less than 5% from China. Last quarter, 40% plus. Wow. Okay. Yeah.

Speaker 1 | 38:47 - 38:58
So we and that's innovation. That's like discovery, right? So we're and why is it? Why are why are there why is that growing so fast in China? They have just as many scientists as us.

Speaker 1 | 38:58 - 39:13
They're just as smart as our scientists. They get paid less. And remember, it's like a hands in the lab. You got to do science is driven by experimental work. So if you now have more experimentalists in China and you get more research per dollar, I don't see why they don't win in research.

Speaker 1 | 39:13 - 39:33
Yeah. And so so from my standpoint, we need to we need to make this change both in how we do experimental work and bring in like the eyes to just increase our amount of like intellectual horsepower if we're going to keep up in science. And you don't want to be surprised. Right. Like if you know, like DARPA, like the, you know, like the things for the Internet, DARPA.

Speaker 1 | 39:33 - 39:49
Right. Like the the founding point of DARPA was like after Sputnik, when the Russians, like, were the first ones to put a satellite up, and it was created to say, like, we will not be technologically surprised again. It's behind the scenes thing, but it is very important. Right? It's really scary if you get technologically surprised.

Speaker 1 | 39:49 - 39:59
And so I think that that is why it's, I think, important from a national security standpoint, important for the country, important for the species is to is the the rate at which we get scientific discovery.

Speaker 3 | 39:59 - 39:59
Does that

Speaker 1 | 39:59 - 40:12
make sense? Yep. Other thing I'm curious I wanna ask you guys about I mean, God bless Sam and this freaking open eye thing. But, like, you know, when they started that, it was like a pie in the sky research project.

Speaker 3 | 40:12 - 40:12
Yeah.

Speaker 1 | 40:12 - 40:17
Yeah. Right? This is like almost like Bell Labs y kinda, you know, like, whatever. Like, go for it. Everyone's like, it's bullshit.

Speaker 1 | 40:17 - 40:21
Oh, what is this? Nonprofit. All the Okay. But here we go. It's now worth what?

Speaker 1 | 40:21 - 40:22
What was the last round done that? Half 1,000,000,000,000

Speaker 3 | 40:22 - 40:24
or 830,000,000,000.

Speaker 1 | 40:24 - 40:36
Great. 830,000,000,000. All right. So so I I to me, it signals in fundamental research in industry can be valuable. Yep.

Speaker 1 | 40:36 - 40:59
And I think that's also a thing that we've kind of forgot about over the last thirty, forty years because so much of like where the money was was just like engineering, engineering, engineering. And it wasn't really about trying something that was just like, this is probably not going to work, but we should give it a try. Pharma's been like that, but lots of the rest of the economy has not. Does that make sense? Yep.

Speaker 1 | 40:59 - 41:17
And I wonder if that's going to change. Like, I'm curious if you think, like, I don't know, every big industry, like, you know, the chemical industry, like, should everyone just get be like, well, based on these models and like some acceleration in science, like, actually, the most valuable thing Dow Chemical would do would be some fucking crazy breakthrough.

Speaker 3 | 41:17 - 41:17
Mhmm.

Speaker 1 | 41:17 - 41:32
Not, you know, let's do another chemical plan or run the numbers on, like, putting something in Louisiana. But, like, you know, like, but, like, actually, Nick, no, no. We're gonna, like, go for it. Do you see that at all? Like, you know, like, like, do you do you, like, like, you, like You know, I don't know.

Speaker 1 | 41:32 - 41:37
But but that would be, like, one of my naive hopes is the industrial side of the house wakes back up

Speaker 3 | 41:37 - 41:37
Yeah.

Speaker 1 | 41:37 - 41:38
On doing research.

Speaker 3 | 41:38 - 41:41
Yeah. Sonya, I know you have a point of view on this.

Speaker 2 | 41:41 - 42:04
I would say we've seen a few of these. I mean, you mentioned chai earlier. Yeah. I think it's likely to come from researchers on the research side of the house that are fundamentally rethinking, for example, the protein design I think it's my gut instinct is more likely to come from folks like that who are just taking really big swings. And the tricky thing is just the song and dance of how they get funded, especially through we're still in biotech winter.

Speaker 1 | 42:04 - 42:05
Sure.

Speaker 2 | 42:05 - 42:17
Right? And how do they even prove out to the world that like, Hey, we have better discovery engines. We have better candidates. Because I think if there's a real problem in the biotech world, there's asymmetric information. You can't tell.

Speaker 2 | 42:18 - 42:32
Google with isomorphic feels like the closest because it's actually got deep pockets behind it to actually prove that story out. But yeah, my bet would be a vertically integrated research team, taking big one at a time. Yeah. The challenge is, like, funding these companies all the way through.

Speaker 3 | 42:32 - 42:59
Well, I think, to the point on should there be more breakthroughs, more fundamental research, I think the answer is unequivocally yes. Like, that is one of the wonderful dividends, so to speak, that's gonna come out of this whole AI wave. Yeah. And I think phase one is sort of becoming human level intelligent across a bunch of different categories. I think that will largely go to just doing the things that we do today better, faster, cheaper.

Speaker 1 | 42:59 - 43:00
Yep. 100%.

Speaker 3 | 43:00 - 43:06
I think phase two is gonna be becoming super intelligent across specific categories one at a time.

Speaker 1 | 43:06 - 43:06
Yeah.

Speaker 3 | 43:06 - 43:08
And that's where all the breakthroughs are gonna come from.

Speaker 1 | 43:08 - 43:08
Yeah.

Speaker 3 | 43:08 - 43:21
And I feel like we're kind of in this transition phase where we're getting to the point of human level intelligence across a bunch of different things. Yeah. We're about to start being super intelligent in a bunch of different things. Yeah. And we're about to start seeing a bunch of breakthroughs.

Speaker 1 | 43:21 - 43:21
Yeah.

Speaker 3 | 43:21 - 43:27
And so I I I think it's, like, we're within months or years of it becoming really interesting.

Speaker 2 | 43:27 - 43:44
Let me give an example. We just backed this team that did the Alpha Chip project at Google. So they're using AI systems to actually just design chips that perform better than what human chip designers can do. And so I think we're gonna see these pockets of superintelligence in different corners of industry, and there's definitely

Speaker 3 | 43:44 - 43:49
games going What was the AlphaGo move 38 or whatever? '37? I'm back. Always forget the number. I know.

Speaker 3 | 43:49 - 43:51
I thought it was, like, 83. Yeah. 37? Great.

Speaker 1 | 43:51 - 43:52
Yes.

Speaker 3 | 43:52 - 43:53
Like, move 37. Right.

Speaker 1 | 43:53 - 43:54
Yes. Yeah. Like, that kind of stuff.

Speaker 2 | 43:54 - 43:55
Yeah.

Speaker 1 | 43:56 - 44:04
Yeah. I mean, if that's true, right, like and and I think there's two ways to get at it, by the way. Yeah. My secret on this would be, one is the thing you're saying, like, it's gonna be super intelligence. Yeah.

Speaker 1 | 44:04 - 44:16
Right? It'll intuit something that a person wouldn't have. And then, like, I really think if you can solve the problem of greatly accelerating the experimental work, it's almost the same.

Speaker 3 | 44:16 - 44:17
Yeah. The combinatoric approach.

Speaker 1 | 44:17 - 44:34
It's just I you know, like, the you can't some of these, a lot of the physical world stuff is not simulatable. Yeah. Right? And so, the, it's just, can you run that machine faster? And then, importantly, like you're saying, like, can you feed it back and make it smarter based on what it's actually seeing in the world?

Speaker 1 | 44:34 - 44:47
Then, then, okay, like, And then I think if you start to believe you can get those breakthroughs, I do think you have to ask, what's the how do you commercialize? Like, what's venture look like in that scenario? Right? Because you're like, oh, crazy. I got this insane break.

Speaker 1 | 44:47 - 44:54
You know, we got a room temperature semiconductor or, you know, right? Like, now what? Right? And is it like you go to, you go to the big guys, you do it yourself. Right?

Speaker 1 | 44:54 - 44:57
Like, there's a whole thing there. Think it's fascinating.

Speaker 3 | 44:57 - 45:20
Yeah. We we we had this conversation the other day on will the venture capital industry shrink because the cost of producing everything gets cheaper because it becomes so much more efficient? Yeah. And if we analogize back to the cloud transition, when all of a sudden you didn't have to build your own data centers, you could just spin up a cloud service Yep. You might have thought the same thing would happen, but actually the opposite happened.

Speaker 3 | 45:20 - 45:32
There was this explosion in creation Yeah. Which made distribution that much more competitive. Yeah. And so there were a million different companies, but then all of them had to fight so hard to, like, break through the noise. Yeah.

Speaker 3 | 45:32 - 45:42
And I would I would would guess the same thing happens, which is the cost of creation goes down and down and down. Yeah. The cost of distribution goes up because there are just so many different things out there. That's interesting. Yeah.

Speaker 1 | 45:42 - 45:43
That could be right.

Speaker 2 | 45:43 - 45:47
Yeah. Do you think language based foundation models are the right substrates, or do

Speaker 1 | 45:47 - 45:47
you think

Speaker 2 | 45:47 - 45:52
somebody's gotta train like a, you know, ACTG native model?

Speaker 1 | 45:52 - 45:57
Yeah. So, so that is like the, Arc's EVO is an ACTG native model.

Speaker 2 | 45:57 - 45:57
Yeah.

Speaker 1 | 45:57 - 46:08
Right? So it's trained on a trillion bases of DNA, and, and I, think that's awesome. I think it's super exciting. I think it will apply. It'll be like a tool available to the reasoning model to do its job.

Speaker 1 | 46:08 - 46:25
That's already the case. Right? Like, the reasoning model working on, say, even our OpenEye project could go access AlphaFold, design a protein, get it synthesized, add that as a reagent into the project, like that's allowable. Right? And so I think those will end up being powerful tools.

Speaker 1 | 46:25 - 46:38
But I still think I'm I think the reasoning models are really they can do the job of an experimental scientist. And so now we have, like, a thousand experimental scientists in a box. Yeah. That that's already true. I don't need, like, a miracle.

Speaker 1 | 46:38 - 46:41
Right? Like that's and and yeah.

Speaker 2 | 46:41 - 46:47
So here's the question. Yeah. AlphaFold, all these all these papers have come out on how AI is changing drug drug discovery.

Speaker 1 | 46:47 - 46:47
Yeah.

Speaker 2 | 46:47 - 46:50
Do you think the pace of drug discovery has actually accelerated or not?

Speaker 3 | 46:50 - 46:51
Okay. Yeah.

Speaker 1 | 46:51 - 47:04
So let's nerd out now on, like, what the hell you can actually do with bio, which is like a pile of trash all the time. Right? Okay. So so, like, bio is right, like, like, I think the down so, god bless. Like, I I basically, you know, Jurassic Park came out when I was 13.

Speaker 1 | 47:04 - 47:10
All I wanna do in life is, like, make Jurassic Park. Engineering is awesome. Right? Like, like, that's why I'm doing this. Did you

Speaker 2 | 47:10 - 47:12
see that one company that brought back the woolly mammoth?

Speaker 1 | 47:12 - 47:13
Yes. Yeah. Know them well. Yeah. The Yeah.

Speaker 1 | 47:13 - 47:33
Yeah. Yeah. Yeah. Is, like, the ability for, you know, kids someday to design biology like they program computers. Right?

Speaker 1 | 47:34 - 48:00
Like, that is what I want. Like, that's the world I want to exist. And so the question is, like, how the hell do you get there? And one of the issues we have in programming biology, design DNA, genetic engineering, whatever you want to call it, is that the only working app ecosystem is therapeutics. There is like 85% of the market for biotechnology is therapeutics, and then there's like 10% is AG.

Speaker 1 | 48:00 - 48:11
Remember, months onto boogity boogity. Right. Like like that's that's like engineering in plants. And then there's like 5% that's like industrial. Like, you and you have cold water laundry detergent, that's a product of biotechnology.

Speaker 1 | 48:11 - 48:19
There's enzymes in there that break up dirt without you having to make your laundry hot. And so that was the that's 5%.

Speaker 2 | 48:19 - 48:19
Okay.

Speaker 1 | 48:20 - 48:28
That is the totality of apps we've come up with so far for programmable matter compilers, I. E. Cells. It's embarrassing. Okay.

Speaker 1 | 48:28 - 48:38
Right. Like the the fundamentals of this. But again, like, let's imagine computers. The only application for computers was drug discovery. We'd all be like, well, good.

Speaker 1 | 48:38 - 49:00
They're so you know, man, such a pain in the ass with these computers. Right. Like, you know, and so so so there is like a distinction between like what we're really working on at Ginkgo and other places like us, which is like, how do you really make it easier and faster and cheaper to just design biology, make it do new things? Yeah. And then the fact of the matter being that the only apps that really, like, have ROI are drugs.

Speaker 1 | 49:00 - 49:10
Yep. Okay. And drugs have, like, annoying features. The biggest one being, like, the time it takes from, like, inception of the drug to making money

Speaker 2 | 49:10 - 49:10
Mhmm.

Speaker 1 | 49:10 - 49:18
Is a killer. And it and it has to do with regulatory, basically. Like, it's like, well, we don't like to stick things in people. Be careful. All that stuff is fine.

Speaker 1 | 49:18 - 49:26
Then we can get faster on that. China's also eating our lunch. You might have seen this, but they can do a trial in six months. It takes us two and a half years for phase one. It's crazy.

Speaker 1 | 49:26 - 49:30
Australia is actually eating our lunch. I think our FDA will just match Australia

Speaker 3 | 49:30 - 49:31
soon, which

Speaker 1 | 49:31 - 49:38
is great. So so we will get faster. But it's still not like launching a phone app. Okay. And so that does that make sense?

Speaker 1 | 49:38 - 49:54
Yeah. So that does remain like like a problem, I would say. We try there's been a bunch of other attempts at other things, you know, like animal free meat and nutrition like it like it's never quite been good enough to like disrupt another industry yet. Yeah. I would love to see that happen.

Speaker 1 | 49:54 - 50:17
That would be a big accelerant, not just for whatever industry, but ultimately for genetic engineering. And then if you accelerate genetic engineering, you you try to create that flywheel that we got in computers where it keeps going going. Now, that said, it to pick our app of drugs, it has gotten more expensive to develop drugs, not less, year over year for the last twenty five years. Yeah. So that's not great.

Speaker 1 | 50:17 - 50:25
That's the opposite of what should be happening. Right? And so and why is that? Because we do it manually. That's my opinion.

Speaker 1 | 50:25 - 50:34
We have we have not and it's like Baumol's cost disease or whatever. Like, the scientists are getting more expensive. The rent is getting more expensive. That's it. They're actually more productive.

Speaker 1 | 50:34 - 50:48
Like, we give them new tools. Like, we are getting like slightly better, but the majority of the cost is manual work. Yeah. That shit does not get cheaper. And so so that is what I think is the root of it, actually.

Speaker 1 | 50:48 - 51:02
And that's why you see me 15 into this being like retrenching to solve that problem first because I don't believe we really get out of the mud until we've got the people out of the lab. Then from that base, we can start to climb out.

Speaker 2 | 51:02 - 51:02
Yeah.

Speaker 1 | 51:02 - 51:07
Right. Now it's fully automated. You can do all kinds of crazy stuff. And eventually it looks like chips someday. Right?

Speaker 1 | 51:07 - 51:16
It's like alien technology. You you're doing it in some way that humans never remember before chips was vacuum tubes. It was like human scale electronics. Yeah, yeah. And then we were like, Okay, cool.

Speaker 1 | 51:16 - 51:30
Like, let's get you know, we saw the curve that will happen for lab work and genetic engineering, I promise you. But the first step is, like, put down the vacuum tubes, right? Like, get onto some system that does not need people in the middle. Does that make sense?

Speaker 3 | 51:30 - 51:32
How does the application space change?

Speaker 1 | 51:33 - 51:41
I don't know. That's very unpredictable. Well, I'll tell you some things I think I'm excite I'm excited about in the near term. You're familiar with, like, the GLP one drugs. Yeah.

Speaker 1 | 51:41 - 51:49
Right? Lilly's worth close to a trillion dollars. That's great. Like, that that is, in my opinion, like a consumer product. I'm I'm on the clips.

Speaker 1 | 51:49 - 52:00
It's awesome. Best thing that it is like the best thing since the iPhone. You don't think about food. It's like you get like you get to spend your day thinking about work or kids, whatever else you want to do. You don't have to, like, think about, oh, I got to intermittent fast through lunch or I'm going be obese.

Speaker 1 | 52:00 - 52:04
Right? Like, you can like you can just get your willpower back. It's awesome. Okay. Right.

Speaker 1 | 52:04 - 52:16
Awesome. But that's to me a the reason it's worth so much money is because it's not treating a disease. Right. Like the the biotech industry, the therapeutics industry today is really the disease industry. Yeah.

Speaker 1 | 52:16 - 52:28
Right. And how much of your life and again, it depends on the person, but how much of your life do you have a disease? It's like a small amount of the time. How much of your life do you want to weigh 15 pounds less? How much of your life do you want to sleep better?

Speaker 1 | 52:28 - 52:40
How much of your life do you want to have more muscles? How much of life do want to feel better? Like the applications in the consumer space for biotech are bananas. Oh, it adds two years to your lifespan. What's that worth?

Speaker 1 | 52:40 - 52:49
Like, what is the value of a biotech product that adds five years to lifespan? This is Sequoia Capital. Throw a number at

Speaker 3 | 52:49 - 52:51
it. Depends on your customer.

Speaker 1 | 52:51 - 53:01
50,000,000,000,000. Like like it's infinity. There's no limit on the value of something that would like stack extra years of healthy life on the people's lives. Like, it's nuts. Yeah.

Speaker 1 | 53:01 - 53:08
Right. Like, you know, like that's effectively what our health care system is trying to do. And it's like they can like the total consumption cost of that. Yeah. Right.

Speaker 1 | 53:08 - 53:23
So if you could have that in a pill and a shot. So that but right now, today, we don't even have a good pathway to get something like that approved. Right. Because all of the regulatory, the FDA and everything is is oriented around treating disease. Yep.

Speaker 1 | 53:23 - 53:39
And this is actually where like, oh, the people are like, oh, maha, blah, blah, blah. Like, I think like that line of the maha thing, which is like, hey, actually, it's about not just about disease, but about being healthy. Yeah. When you don't have disease, I think is really good. Yeah.

Speaker 1 | 53:39 - 53:52
Like, I think that's a really good thing for the industry. And so I do think you'll see that that set of things happen. And so that's one half. It's like new drugs there. And then the other one, our first investor out of YC, do you know who was our angel?

Speaker 1 | 53:53 - 53:58
Mr. Brian Johnson. Back when he Love that kid. Yeah. Like, he was, pudgy VC, No way.

Speaker 1 | 53:58 - 54:00
Oh, yeah. Of course. Yeah. Uh-huh. Amazing.

Speaker 1 | 54:00 - 54:07
Not got, like, you know, longevity, like, you know, Yeah. Like, Back when yeah. When he was, like, normal person. Right? Like, yeah, I got like Jack.

Speaker 1 | 54:07 - 54:26
He's awesome now. Right? Like, and so but like what he's done, what's interesting about what Brian's done is he has normalized the monitoring. Like, because I asked him, was like, how are you, know, like, these are like all these interventions. Like, you're like, well, you know, like, like Brian's got a good life, you know, like, would you be like, oh, you're taking some random thing and trying it out?

Speaker 1 | 54:26 - 54:40
Like, is that scary? And he's like, well, I'm monitoring all the time, right? So like every week he's like taking all these tests and everything else is the most measured person, 2,000,000 a year of diagnostic stuff, right? Like, that is the other area. So like, oh, we all love our aura rings and everything.

Speaker 1 | 54:40 - 54:44
This is pathetic. Okay, right? Like, it's great. Your heart rates like it's like telling you nothing. All right.

Speaker 1 | 54:44 - 55:13
Like like the real and I love aura, by the way, I've had this thing for ten years, but like the real meat of what's going on inside your body is molecular. Yeah. So what we really should be doing is like taking a blood sample every week and giving you like a whole readout of a ton of stuff, like longitudinally over time so that you can try different interventions for you and see how it affects you. Like, because that's what actually matters. Like, molecularly, like aging is molecular, right?

Speaker 1 | 55:13 - 55:25
It's not your freaking whatever. And so so like that whole world is stuff like functions getting going and doing tests. Like, I mean, my God, I did it over Christmas, but it's like 10 vials. It's like the worst experience of the entire world. Right?

Speaker 1 | 55:25 - 55:26
Like like that.

Speaker 2 | 55:26 - 55:27
There's the at home stuff now, too.

Speaker 1 | 55:27 - 55:37
Yeah. It but it's but it's so early. Right? That's my point. Like, so I think that line is another place that could be a big, if you're asking about near end apps, biotech, that one is the other one.

Speaker 1 | 55:37 - 55:44
Right? And so I think, yeah, I think you could see that. I think you could see other things like the Glips. Those are ones I'm excited about. Awesome.

Speaker 1 | 55:44 - 55:45
And then I'm always hopeful.

Speaker 2 | 55:46 - 55:47
Jurassic Park.

Speaker 1 | 55:47 - 55:59
Something like that. Yes. You know, right? Like, that there'll just be some other weird thing. And we did just launch a Cloud Lab service at Ginkgo where you can Like, have experiments as cheap as $39 that you can just run.

Speaker 1 | 55:59 - 56:17
And we don't send you anything. We won't send you a sample, but we will send you back data. So, it's like you do the experiment, we run the experiment for you, you got the data back. Right? And so, my last point on this one is like, think, science is thought of as this very, like, precious genius thing.

Speaker 1 | 56:17 - 56:31
But really what it is, is like formalized human curiosity. It's like a process by which humans, of which all of us are curious about things, like, do curiosity right. Like, really try to answer our curiosity. That makes sense. Yep.

Speaker 1 | 56:31 - 56:49
But I and I think everybody's curious. And so I believe that if you drop the cost of like like like a lot of what blocks people from science is actually not like the esoteric ness of it. It's in my view, the lab. Yeah, it is that that is brutal, right? Like, don't have access.

Speaker 1 | 56:49 - 56:57
It is a total gate kept. Like, you cannot get access to one. It's like almost legally you can't get access to one. Right? Like and so there's just this whole thing.

Speaker 1 | 56:57 - 57:13
And I'm like, well, what if that went away? What if people everyday people could go to order an experiment? What if the model would help them design the experiment to ask a question that they have about the world? Would they suddenly ask questions and do these experiments? Would they be would everybody would millions of people want to be scientists?

Speaker 1 | 57:13 - 57:31
Yeah. And I know that sounds like, well, that's nuts, blah, blah, blah. But like, if you rewind the clock, God bless Silicon Valley and the computer industry to the 1960s when it was IBM and it was mainframes and you told people that kids would program computers. Yep. They would say you're fucking insane.

Speaker 1 | 57:32 - 57:50
And so I believe if you do manage to drop the cost of all this stuff, you may have kids and everybody else wanting to just ask original scientific questions and being able to do it. And that would be a cool market, right? And so anyway, all this stuff, I feel, is on the other side of getting this AI for science stuff working, but I'm excited about it.

Speaker 3 | 57:50 - 57:52
Extremely cool vision for the future.

Speaker 2 | 57:52 - 57:55
Great notes to end on. Thank you. Yeah. Very inspiring.

Speaker 1 | 57:55 - 57:55
Thanks for having me on.

---

