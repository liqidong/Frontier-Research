---
type: research_import
source_file: podcast_no_priors.md
imported_at: 2026-04-07T08:41:06.252Z
---

# AI Podcast: No Priors

> 共收集 1 期节目摘要。

---

## AI for Atoms: How Periodic Labs is Revolutionizing Materials Engineering with Co-Founder Liam Fedus

- **发布时间**: 2026/4/3 10:00:00
- **原始链接**: [点击查看](https://www.youtube.com/@NoPriorsPodcast)

### 📜 内容摘要与转录

Speaker 1 | 00:05 - 00:32
Today, know Priors were talking with Liam Fetis. Liam is one of the co creators of ChatGPT, which I think almost everybody uses at this point. He was the VP of post training at OpenAI, and before that was at Google Brain, where he worked on a variety of really early AI innovations. Liam will be telling us a bit about Periodic Labs, his company, which is focused on building an AI foundation lab for atoms. In other words, how do we impact the physical world, material sciences, chemistry, etcetera, using AI?

Speaker 1 | 00:32 - 00:36
Very exciting topic and excited to be talking with him today. Leigh Ann, thank you so much for joining

Speaker 2 | 00:36 - 00:39
us today on No Priors. Yeah. Thank you so much for having us. Great to see you. Yeah.

Speaker 1 | 00:39 - 00:53
So, maybe what we can do I I think you're doing incredibly interesting things in terms of alternative types of models, specifically for material sciences, for the physical world. Effectively, what you're building is, an AI foundation lab for atoms, which I think is fascinating.

Speaker 2 | 00:53 - 00:53
That's

Speaker 1 | 00:53 - 01:03
right. But maybe we can start with this a little bit more of your background. You know, I think you were VP at OpenAI. You worked on one of the first trillion parameter models ever, etcetera. Could you tell us a little bit more about just what got you

Speaker 2 | 01:03 - 01:21
here? So even further back, I was a physics major in undergrad, spent some time doing dark matter research. We had a apparatus that was directionally sensitive to dark matter's direction. Mhmm. So it was very interesting.

Speaker 1 | 01:21 - 01:33
Are there I'd love to come back to this, but why are there so many physicists in AI right now? So you look at Dario Amadi who runs Anthropic. Of course. Yeah. You look at Adam Brown at Google, you look at a variety of people, and they all kind of have these physics backgrounds.

Speaker 2 | 01:33 - 01:41
Yeah. My old manager, Zhaasha, also in physics and non anthropic. Yeah. Why do you think that is? I think it's a great way to think about the world.

Speaker 2 | 01:41 - 01:55
It's like very principled, very hard nosed scientists, very careful. And I don't know. I think it's just it's such a incredible field. You have such high leverage in computer science and AI. Mhmm.

Speaker 2 | 01:55 - 02:14
And so I think a lot of physicists were seeing that. Mhmm. Particularly in like high energy physics. After the discovery of the Higgs, I think a lot of high energy physicists were sort of looking for what's next. Ultimately, it becomes bottlenecked on the new apparatus for pushing the next energy frontier.

Speaker 2 | 02:15 - 02:22
And I think a lot of physicists were looking at their skillset and looking at the progress elsewhere and saying like, hey, I think I could be a huge contributor elsewhere.

Speaker 1 | 02:22 - 02:34
Mhmm. It's just been fascinating to see string theorists and people working on black holes and all sorts of effects moving into AI. Absolutely. Yeah. It almost feels like we're recreating a Manhattan Project or something, except now what we're seeking is different forms of intelligence.

Speaker 1 | 02:34 - 02:35
Yeah, that's right.

Speaker 2 | 02:35 - 02:35
That's right.

Speaker 1 | 02:35 - 02:40
I'm just understand that perspective. Sorry to interrupt. So studied physics, you worked on dark matter. That's right. And

Speaker 2 | 02:42 - 03:07
then in grad school in physics, was always gravitating towards the machine learning problems. I was looking at particle reconstruction and it's thinking effectively machine learning problems. But it felt if I really wanted to push frontier of machine learning, I should be in computer science. So ended up at Google Brain, was overlapping with the first year residents there. Absolutely remarkable group of people, remarkable period for Google Brain.

Speaker 2 | 03:07 - 03:34
I mean, it's the era of when there's the creation of distributed training strategies, mixture of experts, the transformer. It was a really rich period in that history. And it was a fun Cambrian era where people were really pushing the frontier with just a handful of GPUs, really small collaborations. The field was much much earlier, and I think there was a lot of diversity and entropy in the research, and it was very fun. So was kind of

Speaker 1 | 03:34 - 03:36
late twenty tens or so or something like that?

Speaker 2 | 03:36 - 04:00
This was twenty sixteen, twenty seventeen. Mhmm. So Google brand at that point was still really small, and eventually it was subsumed by DeepMind or combined with DeepMind. So I was at Google for many years, mostly just doing architecture work. So was really pushing sparsity that allows for more efficient serving of models at scale and just really pushing the scale of what we could do.

Speaker 2 | 04:00 - 04:13
Towards late twenty twenty two, really became excited about the creation of products. The technology was getting very compelling, and so I ended up at OpenAI with some other Googlers as well. Mhmm.

Speaker 1 | 04:13 - 04:18
And what did you work on specifically at OpenAI? Well, so the goal was we need to come

Speaker 2 | 04:18 - 04:28
up with some productionization of GPT-four. So OpenAI had GPT four. It was pretrained, and there's some, like, Lavrov post trains on

Speaker 1 | 04:28 - 04:29
it. Mhmm.

Speaker 2 | 04:29 - 04:48
And there's questions about, like, okay, how do we turn this incredibly powerful model into products? And we're all spitballing ideas like writing bot, coding bot, very natural at the time. Some of our least interesting ideas were a meeting bot. So it would just sit in a Google Meet, take notes, and then send out like to dos after. But John Truman was very opinionated.

Speaker 2 | 04:48 - 04:56
He's like, we think we should keep it very general. Let's do a chatbot. And that became a large part of the effort for those few months.

Speaker 1 | 04:56 - 05:07
That's what I call it. So you worked on ChatGPT. That's right. And obviously, I felt like that was kind of the starting gun of this whole AI revolution or at least in terms of people's awareness. Like I'd started investing in the area beforehand, Right.

Speaker 1 | 05:07 - 05:25
But it it seemed like almost as a secret up until ChatGPT came out of it, and suddenly everybody realized that there's this powerful technology available. Yes. How did that lead you to materials and atoms and, you know, the physical world again? I know that was sort of your starting point in terms of academics, but what brought you back given how much is being transformed right

Speaker 2 | 05:25 - 05:49
now through language? I think just the inevitability of connecting these systems to the physical world. The opinion that I and others held as periodic was you're not going to see the same kind of acceleration in science and technology unless you start connecting these things to the physical world. Science ultimately isn't sitting in a room thinking really hard. You have to conduct experiments.

Speaker 2 | 05:49 - 06:05
You have to learn from them. You have to interface with reality. And the creation of ChatGPT in late twenty twenty two was a, you know, technology, but it was still far too weak. Like, we couldn't have done periodic on technology of that era.

Speaker 1 | 06:05 - 06:06
Mhmm.

Speaker 2 | 06:06 - 06:23
I think over the next few years past that, we saw ever improving models. We saw reasoning. I think, like, test time inference became really important. That led to more reliable error correction, more reliable tool use, and we see like the rise of coding agents and other agents.

Speaker 1 | 06:23 - 06:23
Mhmm.

Speaker 2 | 06:23 - 06:34
And I think those were foundational technologies necessary to then connect these systems to the physical world. Like, it was just not not possible with, like, the AI technology of 2022.

Speaker 1 | 06:34 - 06:52
I guess the other thing that's missing from the physical world is data or at least data that's easily accessible. So you look at something like, the big foundation models on the language side, and they're basically trained on the Internet as a major corpus. It's augmented in all sorts of ways with other data sources. How you think about that for what you're doing where you're trying to model atoms in the physical world and how all that stuff kind of works?

Speaker 2 | 06:52 - 07:22
Yeah. So experiment. I mean, so we have simulation physics simulations and we have experiment. And, I think exactly as you're pointing out, ML systems are good on the data you've trained them on, on the tasks you've trained them to do. I think sometimes there's this mythology of AGI, ASI, RSI, And I think we see increasingly powerful systems, but they do become limited if they don't have access to the the raw data to actually make informed decisions.

Speaker 1 | 07:22 - 07:28
How much how much data do you need? And so I know that, there's some data scale related

Speaker 2 | 07:28 - 07:28
Yes.

Speaker 1 | 07:29 - 07:44
Research and other things in terms of, how you kind of hill climb towards like a really good model. Yep. How many experiments do you need to run or how many data points do you need? Or how do you think about the diversity of data points you need to generate? I'm a little bit curious, like, what does that actually look like tangibly?

Speaker 2 | 07:44 - 07:56
So there is some generalization from the existing models. So we don't need to reproduce a system that can understand and write English or write code. So we're leveraging And are you

Speaker 1 | 07:56 - 07:58
using open source for that or closed source models or some

Speaker 2 | 07:59 - 08:05
We use a combination. Uh-huh. Yeah. So for example, like Periodic spends zero effort on improving coding models. Mhmm.

Speaker 1 | 08:06 - 08:06
We're, you

Speaker 2 | 08:06 - 08:49
know, incredibly impressed by Codex, ClogCode, and so that's been a huge accelerator for the company, but focused our machine learning efforts where the existing frontiers is not sufficiently good for us. I think going back to the data question, we're leveraging, call it order tens of trillions of tokens that went into open source models. And that's given us very foundational understanding. But once we start moving into specific discovery areas, chemical spaces, we can see a very high level of sample efficiency. So the system isn't starting as like a randomly initialized neural net, it has a strong prior on the world.

Speaker 2 | 08:49 - 08:51
So where does that prior come from?

Speaker 1 | 08:51 - 08:53
What data that informs that? Just general

Speaker 2 | 08:53 - 08:56
Just like papers, the Internet as you're pointing out.

Speaker 1 | 08:56 - 08:57
Yeah.

Speaker 2 | 08:57 - 09:25
However, that's insufficient. One of the engineers on our team was looking at a reported material property, and it was just sort of extracted values from literature. Was really interesting to see the reported value spanned many orders of magnitude. And so you train an ML system on that, and it's like, well, the best you can do is model this distribution, but you're no closer to like a ground truth. And that's where experimental data comes in where you now have a grounding in this.

Speaker 2 | 09:25 - 09:52
Mhmm. But really important, it's not just like a pool of data. It's this interactive closed loop system that is so powerful. Once you have the experimental data, you can look through it, you can look for aberrations, you can look for patterns, you can look for consistency with simulation data, with literature, and then that helps drive the next set of experiments. So it's not just a pool of data, it's a very active loop.

Speaker 1 | 09:52 - 09:57
I see. And then how do you think about adversity data? So I look at something like AlphaFold or some of the protein folding

Speaker 2 | 09:57 - 09:58
Yep.

Speaker 1 | 09:59 - 10:31
Related models, which are amazing, right, if you think about it. I used to work as a biologist and we would A crystal structure would take years if it happened at all because you weren't necessarily certain if you could crystallize the specific protein under certain re aging conditions in a way that would be performant for actual crystal oxalography and everything or NMR or whatever approach you took for structure. And then AlphaFold comes out and you can just arbitrarily model anything on the protean world, which was amazing as a breakthrough. But it was a very specific dataset that already existed that had lots and lots and lots of structures. Over decades.

Speaker 1 | 10:31 - 10:37
Over decades of work. How hard Do you have to bootstrap that for every single materials domain or do you choose specific ones that

Speaker 2 | 10:37 - 11:00
you think can then generalize? We have seen internally the greatest advances where we have an abundance of data in some space, and that that has led to the highest rate of acceleration internally. But I think you can think of different levels of generalization. And for systems that are strongly governed by quantum mechanical effects, there is some generalization there.

Speaker 1 | 11:00 - 11:00
I

Speaker 2 | 11:00 - 11:20
see. But if you produce a system that has modeled quantum mechanical objects really accurately, it's not really helping much on fluid dynamics or another level of abstraction. And so the generalization we're seeing is quite good, but there's almost like a first principle as you

Speaker 1 | 11:20 - 11:31
can Oh, that's so interesting. So you could do like, here are the basic steps of chemical synthesis, here's quantum mechanics, here's different aspects of how atoms interact in general or Van der Waals forces or things like that. Absolutely. Oh, so interesting. Yeah.

Speaker 1 | 11:31 - 11:39
That's cool. And then from a architecture perspective, is there anything unique that you're doing or interesting, or can you talk a little bit about how you're actually constructing some of these models on top?

Speaker 2 | 11:39 - 11:51
Yeah. So language models are incredibly powerful. It's a very natural interface, and so we continue to use these. Okay. But we think about them almost as like an orchestration layer.

Speaker 2 | 11:51 - 12:33
So that's sort of a a copilot assistant, but also like a system that can direct experiments. And it's orchestrating other specialized models as well. So we do construct neural nets that are specially designed for atomic systems where there's like some symmetry awareness, and those have much lower latency and they've been like fine tuned for that. And so basically, you kind of think of this orchestrating layer that can ingest literature, it can go through our experimental data, it can go through different modalities, but they can also use specialized neural nets as tools, as reward functions. So it's like an overall system.

Speaker 1 | 12:33 - 12:39
Okay. Yeah. That makes a lot of sense. Yeah. I've seen a lot of people architect those sorts of approaches even for things like customer support or other areas.

Speaker 1 | 12:39 - 12:44
Like, it seems like it's the common architecture that's emerging as you're doing these different use cases of those Yeah.

Speaker 2 | 12:45 - 12:47
Yep. But transformers have been very powerful.

Speaker 1 | 12:47 - 13:09
Yeah. And that's really cool. So if I look at the language world, one of the things that was pretty unique about it, and it's the reason that I think these companies like OpenAI, Anthropic, and others are growing so fast, is it just plugged into a very big domain of human existence, is all language. And all language means enterprise software and enterprise interactions, and it means consumer behavior is basically how we interact with the world. Yes.

Speaker 1 | 13:09 - 13:28
It seems like there's a little bit more of a leap for other areas. So example, in robotics, there's really interesting things, different types of robots that exist in the world, but the footprint of that is quite limited relative to language. And the same seems to be true for material sciences. So how do you think about where you're going to commercialize this first or who you're going to work with, or are there specific domains of products that you're working on first?

Speaker 2 | 13:28 - 13:52
So we've begun working very closely with scientists. We've treated periodic as our customer zero and seeing how can we transform how this field of science is done. Mhmm. But there's huge opportunities across all of these industries, all these enterprises that are interfacing with the physical world. People who are bottlenecked by materials engineering, process engineering.

Speaker 2 | 13:52 - 14:21
And again, those are kind of this like the same natural interfaces where engineers are asking questions about their data, they're trying to find aberrations, they're trying to debug machinery, they're trying to get to a better formulation. It's actually quite universal thing as well. And so we've kinda created our little testing ground internally, and now we're sufficiently excited about the tech we've been building and to see this acceleration for advanced manufacturing more broadly.

Speaker 1 | 14:21 - 14:39
And is your model gonna be developing materials for other third parties? Is it developing your own materials that you then sell in the market? Because it almost reminds me a little bit of a biotech model. Yeah. Where in biotech, you can either partner with a big pharma and then effectively help them create a drug and take a royalty on it, or you can build your own drugs.

Speaker 1 | 14:39 - 14:41
Do you think about that in the context of what you're doing?

Speaker 2 | 14:42 - 15:10
We're thinking about us ourselves as an intelligence layer for for these companies. So you can think about system of record, control plane for different experiments and getting to solutions. But like you're saying, there is a very interesting aspect of some breakthroughs here could have really high value, and it might be more akin to a discovery model like we've seen in biotech and elsewhere. But starting thinking about our just as a software business.

Speaker 1 | 15:10 - 15:11
Have you ever heard the Diamond very fast.

Speaker 2 | 15:11 - 15:12
Yeah. Yep.

Speaker 1 | 15:12 - 15:18
Have you heard of the Diamond Age? No. I haven't actually. The Neil Stevenson book. It's basically this book about it was written in the nineties.

Speaker 1 | 15:18 - 15:33
Okay. And there's two key concepts in it. One key concept is there's effectively an AI tutor that's unleashed on the world and it kind of teaches huge numbers of young girls all sorts of skills. This is a very interesting thing about AI education. Then in parallel Why AI particular?

Speaker 1 | 15:34 - 15:49
Basically, this AI research scientist creates a primer for his daughter, and the Chinese steal it and clone it and distribute it across the country. And because he built it for young girls, it's something that every young girl in China has it. Right. Right. So that's the reason.

Speaker 1 | 15:49 - 15:51
It's a very China theft of IP kind

Speaker 2 | 15:51 - 15:52
of thing.

Speaker 1 | 15:52 - 16:09
And then the other part of the book is about matter pipes into everybody's homes and they all have three d printers, and you download blueprints and it just creates whatever you need in the physical world. And some people start evolving different nanobots to do different things. It's this very advanced kind of AI plus materials kind of future world.

Speaker 2 | 16:09 - 16:10
Yes.

Speaker 1 | 16:10 - 16:16
What is your vision or conception of what our world looks like in ten years assuming periodic is successful?

Speaker 2 | 16:16 - 16:44
Well, I mean, think as you're pointing out, you're going from systems that aren't just writing essays, not just writing software, but to literally generating matter. Mhmm. And I think it has pretty profound implications to semiconductors, aerospace, energy. And I think it's it's incredibly important for can we increase like the pace of just like the physical development of the world? Mean, we see how quickly the digital realm is changing.

Speaker 2 | 16:45 - 17:10
Software engineering now looks wildly different than even six months ago. Mhmm. But I think we see, like, you know, similar opportunities in the physical world. Of course, like, atoms are hard, and so you will have some limits of physics. But just because atoms are hard doesn't mean there's not an order of magnitude or two to speed up just making sense of huge amounts of data and getting to solutions more quickly.

Speaker 2 | 17:11 - 17:31
Yeah. So I think what we're trying to do is give humanity this agency for atomic rearrangement synthesis, and we think it's gonna just be a huge accelerator. So, I mean, if our physical world could keep up at some fraction to our digital world Mhmm. I think life will just feel dramatically different.

Speaker 1 | 17:31 - 17:39
Yeah. It's kind of the revolution that that can Yeah. Really It kind of reminds me of almost the materials equivalent of the agricultural revolution. Yeah. We suddenly had a massive spike in productivity of

Speaker 2 | 17:39 - 17:39
Exactly. How

Speaker 1 | 17:40 - 17:44
And it seems like there's been all sorts of bottlenecks that have constrained us until now that you folks are trying to address.

Speaker 2 | 17:44 - 17:44
That's right.

Speaker 1 | 17:44 - 17:47
Yeah. What aspect of the work that you're doing are

Speaker 2 | 17:47 - 18:28
you most excited about? The iteration between these groups of people. I mean, this is just irreducibly a multidisciplinary problem. We have physicists and chemists working really closely with some of the top AI researchers in the world, working closely with some of the best engineers in the world. And this multidisciplinary, like, close collaboration is just absolutely incredible because seeing firsthand how a field can fundamentally change people who have been doing research for, in some cases, decades in a field and now seeing like, oh, under these systems, under intelligent systems, it could look this very different way.

Speaker 2 | 18:28 - 18:57
And I mean, I use like an analog to machine learning a lot going back to the early Google Brain days where the frontier was pushed forward by a few GPUs and a few people. Now you look at this era where it's really industrialized and there's dozens, hundreds of researchers working together with hundreds of thousands, millions of GPUs dictated and driven by scaling laws. Everything is about scaling. It's given that predictability. It's allowed us to put huge amounts of capital into this field.

Speaker 2 | 18:58 - 19:40
And I think the physical sciences, physical engineering will have a very similar property where we establish these scaling properties and bring that mindset. And so periodic in this field is really thinking about how do we bring much larger scale sets of experiments to bear on this. And intelligence systems have enabled this, automation has enabled this, and you really need both. An improvement to automation where you can soon become create bottlenecks in intelligence. And, I mean, the scientists very much feel this where they're not used to working at that level of throughput, and they just can't simply make sense of so much data.

Speaker 2 | 19:40 - 19:41
So interesting. Yeah. So I

Speaker 1 | 19:41 - 19:52
guess in terms of scale here, one of the real benefit one of the things that's really benefited the the frontier labs on the LLM side is just scale of capital and therefore scale of GPU and scale of data.

Speaker 2 | 19:52 - 19:53
Of course.

Speaker 1 | 19:54 - 19:57
Is this similarly a capital intensive area in your mind?

Speaker 2 | 19:57 - 20:28
Yeah. We will require more capital. GPUs are so extraordinarily expensive. And what's interesting is just the compute costs relative to physical infrastructure is actually surprising where, you know, so much money is spent on the compute that the physical infrastructure sometimes is actually lower, but, you know, has very large lead times and there's intrinsic difficulty of having these well calibrated, well functioning physical systems. But from a capital perspective, it's primarily a compute cost.

Speaker 1 | 20:28 - 20:47
Yeah. It's really interesting if you look up the cost of a Stanford postdoc for example, relative to a machine learning engineer, it's such a big difference. Absolutely. Takeaway is that many people working in science, particularly in academic setting are very under compensated relative to sort of their societal value. Absolutely.

Speaker 1 | 20:47 - 21:02
And so I always like it when companies kind of help bring people into the fold in terms of both human impact, but also that ability to do things at real scale and really do things a different way. So it must be very exciting for the people on your team.

Speaker 2 | 21:02 - 21:06
Yeah. Some of the scientists who've joined us are among the best in the world and

Speaker 1 | 21:06 - 21:15
it's been absolutely incredible working with them. Yeah. It sounds like you've built such an amazing interdisciplinary team. Are there specific roles that you're actively looking for right now or key things that you

Speaker 2 | 21:15 - 21:40
really want to hire up? Absolutely. So on our site, we have decomposed the world into bits and atoms. It's a loose taxonomy, But on bit side, we're really thinking about mid training, pretraining roles from the AI side, always more infrastructure roles. And on atom side, like control engineering, system engineering, but also now thinking too about spanning that with product engineering.

Speaker 2 | 21:41 - 21:41
Okay.

Speaker 1 | 21:41 - 21:42
Yeah. I call it

Speaker 2 | 21:42 - 21:42
more active.

Speaker 1 | 21:42 - 22:06
Yeah. Really cool. So I think one of the things that everybody's really thinking deeply about or is excited about right now is AGI, ASI, sort of these advanced systems that are as good as humans or better than humans at different things or are very generalizable in terms of their abilities to do a broad swath of things. How do you think about that, but in the context of what's happening over the overall foundation model curve? Because obviously you were very integral in terms of the development of some of these systems.

Speaker 1 | 22:06 - 22:10
And then how do you think about that applied specifically to some of the areas you're working in?

Speaker 2 | 22:10 - 22:37
I think one fallacy is thinking about intelligence as a scaler. We've consistently seen these systems have a very odd spikiness, and it's actually possible to architect a system that is world class on some math domain, but then you could do some perturbations to the questions and actually degrade it substantially. So it's like a bad high school student. And so there's this odd spikiness to these systems.

Speaker 1 | 22:37 - 22:41
So basically, you can make a system that's like a genius at one thing and not very good at a bunch of other stuff.

Speaker 2 | 22:41 - 23:13
And I guess the point I was making is those fields can actually be quite adjacent. So sometimes the generalization can be non intuitive. But one way I think about recursive self improvement is really kind of akin to neural architecture search from, you know, roughly ten years ago. And I think there's a very clear path for software engineering. So these systems have become so incredibly impressive on this domain as a result of huge amounts of data, really cheap verifiable environments.

Speaker 2 | 23:13 - 23:30
Like, you know, you can check Unitesco from failing to passing with just a few CPUs. It's basically instantaneous. There's no domain expertise gap between an AI researcher or software engineer. And obviously, this will become and is becoming a larger contributor to the next generation of the system.

Speaker 1 | 23:30 - 23:42
When do think it just flips into we just everything is machine self improvement versus human directed or or needs a lot of human intervention? So do you think that's two years away? Do you think that's five years away? Do you think it's ten years away?

Speaker 2 | 23:42 - 24:01
Well, guess, like, building on what I was saying is I think there's a domain caveat to that. Sure. So rolling forward that software engineering self improvement, I think you're going to have a system that can write complete repositories, identify bugs, refactor code, but it doesn't suddenly understand biology.

Speaker 1 | 24:02 - 24:02
Sure.

Speaker 2 | 24:02 - 24:21
Right? It's just like there's a domain gap there in knowledge. Yeah. But even beyond that, there's sets of strategies done in software engineering that differ from scientific or engineering strategies. So it's You're not operating under It's not like decision making under uncertainty to the same degree.

Speaker 2 | 24:21 - 24:31
It's like very verifiable, and that's driven so much of our work. Mhmm. So in that domain, I think it's happening now ish.

Speaker 1 | 24:31 - 24:31
Mhmm.

Speaker 2 | 24:31 - 24:56
And I think we'll see the same thing too for AI research. That's a slower outer loop because now the experiment isn't just checking some unit tests passing, but it's checking what was the scaling property, did this model converge, what's the generalization of the system. That requires GPUs, that requires many hours of experiments, but I think that will also will And those are

Speaker 1 | 24:56 - 25:04
all evals that people use today as they're looking at existing models. Absolutely. So they do have that utility function, that feedback loop that can be just driven by self learning.

Speaker 2 | 25:04 - 25:27
That's right. That's right. But again, the connection of these things to the physical world is going to be so critical because both of those systems are being trained in a closed loop against that domain. So it's a closed loop for doing software engineering, a closed loop for doing AI research, and that's the premise of periodic. Like, we need to have these closed loops of actually doing science, of actually doing engineering.

Speaker 2 | 25:27 - 25:39
And these two domains are how I think the rest of the world will go with some delay. And this is again like the foundational technology that we're

Speaker 1 | 25:39 - 25:56
Super interesting. Do you think you need sufficiently good robotic systems in order to have that closed loop for what you're doing? In other words, do you need something like PIE or Skills or something else to work in order for Periodic to hit that escape velocity in terms of a closed loop system?

Speaker 2 | 25:56 - 26:17
No. But it's a huge accelerator. Mhmm. The goal for Periodic is to generate high quantity, high quality data, diverse data, and automation is assistance to that. So right now, we employ people as well, and we have autonomous parts that are just very reliable.

Speaker 2 | 26:18 - 26:50
If you had a dextrous humanoid who could wander into an unstructured lab and make sense and follow instructions reliably, that would be a huge accelerator. Right now, the automation of physical systems is requires a very careful design, and it's slow. But I think with improvements in robotics, it's just going to accelerate this. But already, the reliability of these sort of like hybrid systems is sufficient to produce huge amounts of reliable data, but it's just gonna accelerate us further.

Speaker 1 | 26:50 - 27:04
Yeah. One of the reasons I ask is I used to run this company, Color, and we built our own liquid handling robotic systems. Right? We buy liquid handling robots, but then we have to adjust them dramatically. We had like cameras that would use ML to monitor the system and sort of make adjustments.

Speaker 1 | 27:04 - 27:34
We had to three d print parts to decrease vibrations on the platform because we were dealing with such small volumes of liquid. And so there's enormous amounts of customization versus just having And the firmware for it was awful and writing against that was painful versus just having a robotic system that would work like a modern system in all the ways that you'd conceive that. And that's what the reason that I was asking is if you really want to do high throughput experiments, you need these underlying systems to be able to do all the liquid handling and to do all the titration stuff and all the rest of it.

Speaker 2 | 27:35 - 27:47
Yeah. That's right. I mean, think it's look. Right now, we're using almost like more like off the shelf robotics. It's very simple, very commoditized, not doing a huge amount of innovation on that front.

Speaker 2 | 27:47 - 27:59
But again, as these more general robotic systems come to hit this reliability threshold, it's gonna be a massive accelerator for spinning up new labs as well.

Speaker 1 | 27:59 - 28:19
Yeah. You've seen such a wide range of different things happen in the AI world since Indeed. You're working with Google, I guess at this point about a decade ago. And so you were there during the birth of the transformer model, you were there, for the birth of ChatGPT. What are you most excited about outside of Periodic over the next few years in terms of what's happening with AI?

Speaker 2 | 28:19 - 28:21
I mean, of course, robotics.

Speaker 1 | 28:21 - 28:21
Mhmm.

Speaker 2 | 28:21 - 28:27
Again, I'm like I'm just so excited about the interface of AI systems with the physical world.

Speaker 1 | 28:27 - 28:27
Mhmm.

Speaker 2 | 28:27 - 28:33
And we're approaching one angle of that, which is science engineering.

Speaker 1 | 28:33 - 28:34
Mhmm.

Speaker 2 | 28:34 - 28:56
And we need that data in order to make those advances. But simply just agency and control of the physical world via robotics is going to be transformative. So I'm very excited about these interface layers. I think that's gonna be such a massive opportunity. Because, I mean, you know, how many software engineers are there in the world versus people who build, like, the physical world?

Speaker 2 | 28:56 - 29:01
Mhmm. And there's just labor shortages everywhere. So, yeah, I think it's gonna be a very interesting decade.

Speaker 1 | 29:01 - 29:03
Oh, amazing. Well, thank you so much for joining us today.

Speaker 2 | 29:03 - 29:06
Yeah. Well, thanks so much. Was really really good chatting Yeah.

Speaker 3 | 29:08 - 29:24
Find us on Twitter no priors pod. Subscribe to our YouTube channel if you wanna see our faces. Follow the show on Apple Podcasts, Spotify, or wherever you listen. That way you get a new episode every week. And sign up for emails or find transcripts for every episode at knowpriors.com.

---

